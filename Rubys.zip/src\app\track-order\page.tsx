import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';

export default function TrackOrderPage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <nav className="flex mb-6 text-sm text-gray-600">
          <a href="/" className="hover:text-ruby-600">Home</a>
          <span className="mx-2">/</span>
          <span className="text-gray-900">Track Order</span>
        </nav>
        <h1 className="text-3xl font-bold text-gray-900 mb-6">Track Your Order</h1>
        <p className="text-gray-600 mb-8">Enter your order details to track your shipment status.</p>
        <div className="card p-6">
          <form className="space-y-4">
            <div>
              <label htmlFor="orderId" className="block text-sm font-medium text-gray-700 mb-2">
                Order ID / Tracking Number
              </label>
              <input
                type="text"
                id="orderId"
                className="input-field"
                placeholder="Enter your order ID"
              />
            </div>
            <div>
              <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-2">
                Phone Number
              </label>
              <input
                type="tel"
                id="phone"
                className="input-field"
                placeholder="03XX XXXXXXX"
              />
            </div>
            <button type="submit" className="btn-primary w-full">
              Track Order
            </button>
          </form>
        </div>
      </main>
      <Footer />
    </div>
  );
}
