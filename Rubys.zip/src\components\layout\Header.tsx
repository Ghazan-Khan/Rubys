'use client';

import { useState } from 'react';
import Link from 'next/link';
import { 
  MagnifyingGlassIcon, 
  ShoppingCartIcon, 
  HeartIcon, 
  UserIcon,
  Bars3Icon,
  XMarkIcon,
  ChevronDownIcon
} from '@heroicons/react/24/outline';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [cartCount] = useState(0);

  const categories = [
    { name: 'Fashion & Clothing', href: '/category/fashion-clothing' },
    { name: 'Electronics', href: '/category/electronics' },
    { name: 'Home & Living', href: '/category/home-living' },
    { name: 'Beauty & Health', href: '/category/beauty-health' },
    { name: 'Sports & Fitness', href: '/category/sports-fitness' },
    { name: 'Books & Stationery', href: '/category/books-stationery' },
  ];

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      {/* Announcement Bar */}
      <div className="bg-ruby-600 text-white text-center py-2 px-4">
        <p className="text-sm font-medium">
          🚚 Free Delivery on Orders Above Rs. 2,000 | COD Available | Serving KPK & All Pakistan
        </p>
      </div>

      {/* Main Header */}
      <div className="border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex-shrink-0">
              <Link href="/" className="flex items-center">
                <div className="text-2xl font-bold text-ruby-600">
                  Ruby's<span className="text-charcoal-900">.pk</span>
                </div>
              </Link>
            </div>

            {/* Search Bar - Desktop */}
            <div className="hidden md:flex flex-1 max-w-lg mx-8">
              <div className="relative w-full">
                <input
                  type="text"
                  placeholder="Search for products..."
                  className="w-full pl-4 pr-12 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-ruby-500 focus:border-transparent"
                />
                <button className="absolute right-2 top-1/2 transform -translate-y-1/2 p-1.5 text-gray-400 hover:text-ruby-600">
                  <MagnifyingGlassIcon className="h-5 w-5" />
                </button>
              </div>
            </div>

            {/* Header Actions */}
            <div className="flex items-center space-x-4">
              <Link href="/account" className="hidden sm:flex items-center space-x-1 text-gray-700 hover:text-ruby-600 transition-colors">
                <UserIcon className="h-6 w-6" />
                <span className="text-sm font-medium">Account</span>
              </Link>
              <Link href="/wishlist" className="flex items-center text-gray-700 hover:text-ruby-600 transition-colors">
                <HeartIcon className="h-6 w-6" />
              </Link>
              <Link href="/cart" className="flex items-center space-x-1 text-gray-700 hover:text-ruby-600 transition-colors relative">
                <ShoppingCartIcon className="h-6 w-6" />
                {cartCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-ruby-600 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                    {cartCount}
                  </span>
                )}
                <span className="hidden sm:block text-sm font-medium">Cart</span>
              </Link>
              <button
                className="md:hidden p-2 text-gray-700"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
              >
                {isMenuOpen ? <XMarkIcon className="h-6 w-6" /> : <Bars3Icon className="h-6 w-6" />}
              </button>
            </div>
          </div>

          {/* Mobile Search */}
          <div className="md:hidden pb-3">
            <div className="relative">
              <input
                type="text"
                placeholder="Search for products..."
                className="w-full pl-4 pr-12 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-ruby-500"
              />
              <button className="absolute right-2 top-1/2 transform -translate-y-1/2 p-1.5 text-gray-400">
                <MagnifyingGlassIcon className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Menu */}
      <nav className="hidden md:block bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center space-x-8 h-12">
            <Link href="/shop" className="text-gray-700 hover:text-ruby-600 font-medium transition-colors">
              All Products
            </Link>
            {categories.map((category) => (
              <Link
                key={category.name}
                href={category.href}
                className="text-gray-700 hover:text-ruby-600 font-medium transition-colors"
              >
                {category.name}
              </Link>
            ))}
            <Link href="/track-order" className="text-gray-700 hover:text-ruby-600 font-medium transition-colors">
              Track Order
            </Link>
          </div>
        </div>
      </nav>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white border-b border-gray-200">
          <div className="px-4 py-2 space-y-1">
            <Link href="/shop" className="block py-2 text-gray-700 hover:text-ruby-600 font-medium">
              All Products
            </Link>
            {categories.map((category) => (
              <Link
                key={category.name}
                href={category.href}
                className="block py-2 pl-4 text-gray-600 hover:text-ruby-600"
              >
                {category.name}
              </Link>
            ))}
            <Link href="/track-order" className="block py-2 text-gray-700 hover:text-ruby-600 font-medium">
              Track Order
            </Link>
            <Link href="/account" className="block py-2 text-gray-700 hover:text-ruby-600 font-medium">
              My Account
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}
