# Ruby's.pk - Premium Online Shopping in Pakistan

A complete, production-ready e-commerce website built for Ruby's.pk, serving customers across Pakistan with a special focus on Khyber Pakhtunkhwa (KPK).

## Features

- 🛍️ **Complete E-commerce Platform** - Product catalog, cart, checkout, and order management
- 📱 **Mobile-First Design** - Responsive across all devices
- 🚚 **Pakistan-Focused** - PKR currency, Pakistani phone validation, province/city selection
- 💳 **Payment Options** - Cash on Delivery (COD) and Bank Transfer support
- 🎯 **KPK Priority** - Optimized for Khyber Pakhtunkhwa delivery
- 🔍 **SEO Optimized** - Complete SEO setup with meta tags, structured data, sitemap
- ⚡ **Performance Optimized** - Fast loading with Next.js 15 and Tailwind CSS
- 🔒 **Secure** - Built with security best practices
- 🌐 **Bilingual Ready** - Structure for English and Urdu support

## Tech Stack

- **Frontend:** Next.js 15 with TypeScript
- **Styling:** Tailwind CSS
- **Icons:** Heroicons
- **UI Components:** Headless UI

## Getting Started

### Prerequisites
- Node.js 18+ and npm
- Git

### Installation

1. Clone the repository
```bash
git clone <repository-url>
cd rubys-pk
```

2. Install dependencies
```bash
npm install
```

3. Set up environment variables
```bash
cp .env.example .env.local
```

4. Run development server
```bash
npm run dev
```

5. Open [http://localhost:3000](http://localhost:3000) in your browser

## Project Structure

```
src/
├── app/                 # Next.js App Router pages
├── components/          # Reusable React components
│   ├── layout/         # Header, Footer
│   └── home/           # Home page components
├── lib/                # Utility functions
├── styles/             # Additional styles
└── types/              # TypeScript type definitions
```

## Key Pages

- **Home** - Hero banner, featured categories, product grids
- **Shop** - Product catalog with filtering and search
- **Cart** - Shopping cart management
- **Checkout** - Secure checkout process
- **Track Order** - Order tracking functionality
- **Account** - Customer account management
- **About Us** - Company information
- **Contact** - Contact form and information
- **Policies** - Shipping, Returns, Privacy, Terms

## SEO Features

- Unique meta titles and descriptions for all pages
- Structured data (JSON-LD) for products and organization
- XML sitemap generation
- Robots.txt configuration
- Open Graph and Twitter Card support
- Canonical URLs
- Breadcrumb navigation

## Deployment

1. Build the application
```bash
npm run build
```

2. Start production server
```bash
npm start
```

## Contributing

This is a custom-built e-commerce solution for Ruby's.pk. All source code is owned by the client.

## License

Proprietary - All rights reserved by Ruby's.pk

## Contact

- Website: [https://rubys.pk](https://rubys.pk)
- Email: support@rubys.pk
- Location: Peshawar, Khyber Pakhtunkhwa, Pakistan
