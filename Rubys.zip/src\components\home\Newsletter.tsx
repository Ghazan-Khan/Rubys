export default function Newsletter() {
  return (
    <section className="py-12 bg-ruby-600">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="text-3xl font-bold text-white mb-4">
          Stay Updated with Ruby's.pk
        </h2>
        <p className="text-ruby-100 mb-8 max-w-2xl mx-auto">
          Subscribe to our newsletter for exclusive deals, new arrivals, and updates on latest offers. 
          We respect your privacy.
        </p>
        <div className="max-w-md mx-auto flex flex-col sm:flex-row gap-3">
          <input
            type="email"
            placeholder="Enter your email address"
            className="flex-1 px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-white"
          />
          <button className="bg-charcoal-900 hover:bg-charcoal-800 text-white font-medium px-6 py-3 rounded-lg transition-colors">
            Subscribe
          </button>
        </div>
        <p className="text-xs text-ruby-200 mt-3">
          By subscribing, you agree to our Privacy Policy
        </p>
      </div>
    </section>
  );
}
