import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  metadataBase: new URL('https://rubys.pk'),
  title: {
    default: "Ruby's.pk - Premium Online Shopping in Pakistan | KPK & Nationwide Delivery",
    template: "%s | Ruby's.pk"
  },
  description: "Shop premium quality products online at Ruby's.pk. Fast delivery across Pakistan, especially Khyber Pakhtunkhwa (KPK). Cash on Delivery available. Best prices in Pakistan.",
  keywords: ["online shopping pakistan", "ruby's pakistan", "kpk online shopping", "peshawar online shopping", "cash on delivery pakistan", "pakistan ecommerce"],
  authors: [{ name: "Ruby's.pk" }],
  creator: "Ruby's.pk",
  publisher: "Ruby's.pk",
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  openGraph: {
    type: "website",
    locale: "en_PK",
    url: "https://rubys.pk",
    title: "Ruby's.pk - Premium Online Shopping in Pakistan",
    description: "Shop premium quality products online at Ruby's.pk. Fast delivery across Pakistan, especially KPK.",
    siteName: "Ruby's.pk",
  },
  twitter: {
    card: "summary_large_image",
    title: "Ruby's.pk - Premium Online Shopping in Pakistan",
    description: "Shop premium quality products online at Ruby's.pk. Fast delivery across Pakistan, especially KPK.",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  verification: {
    google: "your-google-verification-code",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">
        {children}
      </body>
    </html>
  );
}
