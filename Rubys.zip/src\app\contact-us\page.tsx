import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';

export default function ContactUsPage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <nav className="flex mb-6 text-sm text-gray-600">
          <a href="/" className="hover:text-ruby-600">Home</a>
          <span className="mx-2">/</span>
          <span className="text-gray-900">Contact Us</span>
        </nav>
        <h1 className="text-3xl font-bold text-gray-900 mb-6">Contact Us</h1>
        <p className="text-gray-600 mb-8">Get in touch with our customer support team. We're here to help!</p>
        <div className="grid md:grid-cols-2 gap-8">
          <div className="card p-6">
            <h2 className="text-xl font-semibold mb-4">Send us a Message</h2>
            <form className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
                <input type="text" className="input-field" placeholder="Your full name" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                <input type="email" className="input-field" placeholder="your.email@example.com" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Phone Number</label>
                <input type="tel" className="input-field" placeholder="03XX XXXXXXX" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Message</label>
                <textarea className="input-field" rows={4} placeholder="How can we help you?"></textarea>
              </div>
              <button type="submit" className="btn-primary w-full">Send Message</button>
            </form>
          </div>
          <div className="space-y-6">
            <div className="card p-6">
              <h3 className="font-semibold mb-3">Customer Support</h3>
              <div className="space-y-2 text-gray-600">
                <p>📧 support@rubys.pk</p>
                <p>📍 Peshawar, Khyber Pakhtunkhwa, Pakistan</p>
              </div>
            </div>
            <div className="card p-6">
              <h3 className="font-semibold mb-3">Business Hours</h3>
              <div className="space-y-1 text-gray-600 text-sm">
                <p>Monday - Saturday: 9:00 AM - 6:00 PM</p>
                <p>Sunday: Closed</p>
                <p className="text-ruby-600 font-medium">Response time: Within 24 hours</p>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
