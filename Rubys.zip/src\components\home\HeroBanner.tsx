import Link from 'next/link';

export default function HeroBanner() {
  return (
    <section className="relative bg-gradient-to-r from-ruby-600 to-ruby-700 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24">
        <div className="grid lg:grid-cols-2 gap-8 items-center">
          <div>
            <h1 className="text-4xl lg:text-5xl font-bold mb-6 leading-tight">
              Premium Online Shopping in Pakistan
            </h1>
            <p className="text-xl mb-8 text-ruby-100 leading-relaxed">
              Discover quality products at unbeatable prices. Fast delivery across Pakistan, 
              with special focus on Khyber Pakhtunkhwa. Cash on Delivery available.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/shop" className="bg-white text-ruby-700 hover:bg-gray-100 font-semibold px-8 py-3 rounded-lg transition-colors text-center">
                Shop Now
              </Link>
              <Link href="/track-order" className="border-2 border-white text-white hover:bg-white hover:text-ruby-700 font-semibold px-8 py-3 rounded-lg transition-colors text-center">
                Track Order
              </Link>
            </div>
            <div className="mt-8 flex items-center space-x-6 text-sm">
              <div className="flex items-center space-x-2">
                <span className="text-2xl">🚚</span>
                <span>Nationwide Delivery</span>
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-2xl">💳</span>
                <span>Cash on Delivery</span>
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-2xl">🔒</span>
                <span>Secure Shopping</span>
              </div>
            </div>
          </div>
          <div className="hidden lg:block">
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 text-center">
              <div className="text-6xl mb-4">💎</div>
              <h2 className="text-2xl font-bold mb-2">Quality Assured</h2>
              <p className="text-ruby-100">Premium Products • Great Prices • Trusted Service</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
