import { 
  TruckIcon, 
  ShieldCheckIcon, 
  CreditCardIcon,
  PhoneIcon 
} from '@heroicons/react/24/outline';

export default function TrustIndicators() {
  const indicators = [
    {
      icon: TruckIcon,
      title: 'Fast Delivery',
      description: 'Across Pakistan & KPK'
    },
    {
      icon: CreditCardIcon,
      title: 'Cash on Delivery',
      description: 'Pay when you receive'
    },
    {
      icon: ShieldCheckIcon,
      title: 'Secure Shopping',
      description: 'Safe & trusted platform'
    },
    {
      icon: PhoneIcon,
      title: 'Customer Support',
      description: 'Here to help you'
    }
  ];

  return (
    <section className="py-8 bg-gray-50 border-y border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          {indicators.map((indicator, index) => (
            <div key={index} className="flex items-center space-x-3">
              <div className="flex-shrink-0">
                <indicator.icon className="h-8 w-8 text-ruby-600" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 text-sm">{indicator.title}</h3>
                <p className="text-xs text-gray-600">{indicator.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
