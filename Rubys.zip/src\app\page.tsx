import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import HeroBanner from '@/components/home/HeroBanner';
import FeaturedCategories from '@/components/home/FeaturedCategories';
import ProductGrid from '@/components/home/ProductGrid';
import TrustIndicators from '@/components/home/TrustIndicators';
import Newsletter from '@/components/home/Newsletter';

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        <HeroBanner />
        <TrustIndicators />
        <FeaturedCategories />
        <ProductGrid title="Featured Products" subtitle="Handpicked items for you" />
        <ProductGrid title="New Arrivals" subtitle="Latest additions to our collection" />
        <Newsletter />
      </main>
      <Footer />
    </div>
  );
}
