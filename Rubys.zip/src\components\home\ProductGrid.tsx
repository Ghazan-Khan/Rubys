import Link from 'next/link';
import { HeartIcon } from '@heroicons/react/24/outline';

interface ProductGridProps {
  title: string;
  subtitle?: string;
}

const sampleProducts = [
  {
    id: 1,
    name: 'Premium Cotton T-Shirt',
    price: 1499,
    originalPrice: 1999,
    image: '👕',
    category: 'Fashion'
  },
  {
    id: 2,
    name: 'Wireless Bluetooth Earbuds',
    price: 3999,
    originalPrice: 5999,
    image: '🎧',
    category: 'Electronics'
  },
  {
    id: 3,
    name: 'Ceramic Mug Set',
    price: 899,
    originalPrice: null,
    image: '☕',
    category: 'Home & Living'
  },
  {
    id: 4,
    name: 'Moisturizing Face Cream',
    price: 1299,
    originalPrice: 1599,
    image: '🧴',
    category: 'Beauty'
  }
];

export default function ProductGrid({ title, subtitle }: ProductGridProps) {
  return (
    <section className="py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h2 className="text-3xl font-bold text-gray-900 mb-2">{title}</h2>
            {subtitle && <p className="text-gray-600">{subtitle}</p>}
          </div>
          <Link href="/shop" className="text-ruby-600 hover:text-ruby-700 font-medium">
            View All →
          </Link>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {sampleProducts.map((product) => (
            <div key={product.id} className="card group">
              <div className="relative">
                <div className="aspect-square bg-gray-100 flex items-center justify-center text-6xl">
                  {product.image}
                </div>
                <button className="absolute top-3 right-3 p-2 bg-white rounded-full shadow-md hover:bg-gray-50 transition-colors">
                  <HeartIcon className="h-5 w-5 text-gray-600" />
                </button>
                {product.originalPrice && (
                  <div className="absolute top-3 left-3 bg-ruby-600 text-white px-2 py-1 rounded text-xs font-medium">
                    Save Rs. {product.originalPrice - product.price}
                  </div>
                )}
              </div>
              <div className="p-4">
                <p className="text-xs text-gray-500 mb-1">{product.category}</p>
                <h3 className="font-semibold text-gray-900 mb-2 line-clamp-2 group-hover:text-ruby-600 transition-colors">
                  {product.name}
                </h3>
                <div className="flex items-center space-x-2 mb-3">
                  <span className="text-lg font-bold text-ruby-600">Rs. {product.price.toLocaleString()}</span>
                  {product.originalPrice && (
                    <span className="text-sm text-gray-500 line-through">Rs. {product.originalPrice.toLocaleString()}</span>
                  )}
                </div>
                <button className="w-full btn-primary text-sm py-2">
                  Add to Cart
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
