import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';

export default function ShopPage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <nav className="flex mb-6 text-sm text-gray-600">
          <a href="/" className="hover:text-ruby-600">Home</a>
          <span className="mx-2">/</span>
          <span className="text-gray-900">Shop</span>
        </nav>
        <h1 className="text-3xl font-bold text-gray-900 mb-6">All Products</h1>
        <p className="text-gray-600 mb-8">Browse our complete collection of quality products at great prices.</p>
        <div className="text-center py-12 bg-gray-50 rounded-lg">
          <p className="text-gray-600">Product catalog will be populated based on available inventory.</p>
        </div>
      </main>
      <Footer />
    </div>
  );
}
