import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';

export default function AboutUsPage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <nav className="flex mb-6 text-sm text-gray-600">
          <a href="/" className="hover:text-ruby-600">Home</a>
          <span className="mx-2">/</span>
          <span className="text-gray-900">About Us</span>
        </nav>
        <h1 className="text-3xl font-bold text-gray-900 mb-6">About Ruby's.pk</h1>
        <div className="prose max-w-none">
          <p className="text-lg text-gray-700 mb-6 leading-relaxed">
            Ruby's.pk is Pakistan's trusted online shopping destination, committed to bringing quality products 
            to customers across the nation with a special focus on Khyber Pakhtunkhwa (KPK).
          </p>
          <h2 className="text-2xl font-semibold text-gray-900 mb-4">Our Mission</h2>
          <p className="text-gray-700 mb-6 leading-relaxed">
            To provide Pakistani customers with access to quality products at competitive prices, 
            backed by reliable delivery, secure payment options including Cash on Delivery, and 
            exceptional customer service.
          </p>
          <h2 className="text-2xl font-semibold text-gray-900 mb-4">Why Choose Ruby's.pk</h2>
          <ul className="list-disc pl-6 space-y-2 text-gray-700 mb-6">
            <li>Quality products at affordable prices</li>
            <li>Fast and reliable delivery across Pakistan</li>
            <li>Special focus on serving KPK regions including Peshawar, Mardan, Abbottabad, Swat and more</li>
            <li>Cash on Delivery available</li>
            <li>Secure and convenient shopping experience</li>
            <li>Dedicated customer support</li>
          </ul>
          <h2 className="text-2xl font-semibold text-gray-900 mb-4">Serving Pakistan</h2>
          <p className="text-gray-700 leading-relaxed">
            We proudly serve customers throughout Pakistan, with priority delivery to Khyber Pakhtunkhwa. 
            Our goal is to make online shopping accessible, reliable, and enjoyable for everyone.
          </p>
        </div>
      </main>
      <Footer />
    </div>
  );
}
