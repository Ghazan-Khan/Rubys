import Link from 'next/link';

export default function FeaturedCategories() {
  const categories = [
    {
      name: 'Fashion & Clothing',
      href: '/category/fashion-clothing',
      image: '👔',
      description: 'Trendy Apparel'
    },
    {
      name: 'Electronics',
      href: '/category/electronics',
      image: '📱',
      description: 'Gadgets & Devices'
    },
    {
      name: 'Home & Living',
      href: '/category/home-living',
      image: '🏠',
      description: 'Furniture & Decor'
    },
    {
      name: 'Beauty & Health',
      href: '/category/beauty-health',
      image: '💄',
      description: 'Cosmetics & Care'
    },
    {
      name: 'Sports & Fitness',
      href: '/category/sports-fitness',
      image: '⚽',
      description: 'Equipment & Gear'
    },
    {
      name: 'Books & Stationery',
      href: '/category/books-stationery',
      image: '📚',
      description: 'Books & Supplies'
    }
  ];

  return (
    <section className="py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Shop by Category</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Browse our wide range of product categories. Find exactly what you're looking for.
          </p>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {categories.map((category) => (
            <Link
              key={category.name}
              href={category.href}
              className="group card p-6 text-center hover:scale-105 transform transition-all duration-200"
            >
              <div className="text-4xl mb-3">{category.image}</div>
              <h3 className="font-semibold text-gray-900 mb-1 group-hover:text-ruby-600 transition-colors">
                {category.name}
              </h3>
              <p className="text-xs text-gray-600">{category.description}</p>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
